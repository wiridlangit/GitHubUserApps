package com.dicoding.restaurantreview.ui

interface UserClickListener {
    fun onUserClicked(username: String)
}
