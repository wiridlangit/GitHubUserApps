package com.dicoding.restaurantreview.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.restaurantreview.R
import com.dicoding.restaurantreview.databinding.ActivityDetailUserBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var progressBar: ProgressBar
    private lateinit var viewModel: UserViewModel
    private lateinit var viewPager: ViewPager2
    private lateinit var adapter: SectionsPagerAdapter
    private lateinit var tabs: TabLayout

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        progressBar = findViewById(R.id.progressBar)
        viewModel = ViewModelProvider(this)[UserViewModel::class.java]

        progressBar.visibility = View.VISIBLE

        viewModel.detailUser.observe(this) { user ->
            if (user != null) {
                binding.usernameTextView.text = user.login
                binding.nameTextView.text = user.name
                binding.followersTextView.text = getString(R.string.followers, user.followers)
                binding.followingTextView.text = getString(R.string.following, user.following)
                progressBar.visibility = View.GONE
                Glide.with(binding.avatarImageView.context)
                    .load(user.avatarUrl)
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(binding.avatarImageView)
            } else {
                // Handle case where user is null
            }
        }

        val username = intent.getStringExtra("username")
        binding.usernameTextView.text = username

        viewModel.fetchDetailUser(username ?: "")

        adapter = SectionsPagerAdapter(this)
        adapter.username = username ?: ""

        viewPager = findViewById(R.id.view_pager)
        tabs = findViewById(R.id.tabs)

        viewPager.adapter = adapter
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab1)
                1 -> getString(R.string.tab2)
                else -> "Unknown"
            }
        }.attach()
    }
}
