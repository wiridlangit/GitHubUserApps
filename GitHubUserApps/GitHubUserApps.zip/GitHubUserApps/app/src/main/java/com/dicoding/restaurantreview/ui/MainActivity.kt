package com.dicoding.restaurantreview.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.restaurantreview.R

class MainActivity : AppCompatActivity(), UserClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: UserAdapter
    private lateinit var viewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = UserAdapter(emptyList(), this)
        recyclerView.adapter = adapter
        progressBar.visibility = View.VISIBLE

        viewModel = ViewModelProvider(this)[UserViewModel::class.java]

        viewModel.fetchUserList("wiridlangit")

        setupSearchView()

        viewModel.users.observe(this) { users ->
            users?.let {
                adapter.updateData(users)
                progressBar.visibility = View.GONE
            } ?: run {
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun setupSearchView() {
        val searchView = findViewById<SearchView>(R.id.searchView)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return if (query.isNullOrEmpty()) {
                    Log.d("MainActivity", "Creating toast")
                    val toast = Toast.makeText(this@MainActivity, "Please enter a username", Toast.LENGTH_SHORT)
                    toast.setGravity(Gravity.CENTER, 0, 0)
                    toast.show()
                    false
                } else {
                    progressBar.visibility = View.VISIBLE
                    viewModel.fetchUserList(query)
                    true
                }
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return true
            }
        })
    }

    override fun onUserClicked(username: String) {
        val intent = Intent(this, DetailUserActivity::class.java)
        intent.putExtra("username", username)
        startActivity(intent)
    }
}
