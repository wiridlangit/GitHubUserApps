package com.dicoding.restaurantreview.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.restaurantreview.data.response.DetailUserResponse
import com.dicoding.restaurantreview.data.response.User
import com.dicoding.restaurantreview.data.retrofit.ApiConfig
import kotlinx.coroutines.launch
import retrofit2.HttpException

class UserViewModel : ViewModel() {

    private val _users = MutableLiveData<List<User>>()
    val users: LiveData<List<User>>
        get() = _users

    private val _detailUser = MutableLiveData<DetailUserResponse?>()
    val detailUser: LiveData<DetailUserResponse?>
        get() = _detailUser

    fun fetchUserList(query: String) {
        viewModelScope.launch {
            try {
                val response = ApiConfig.getApiService().searchUsers(query)
                _users.value = response.body()?.items
            } catch (e: HttpException) {
                // Handle network errors
            }
        }
    }
    fun fetchDetailUser(username: String) {
        viewModelScope.launch {
            try {
                val response = ApiConfig.getApiService().getDetailUser(username)
                if (response.isSuccessful) {
                    _detailUser.value = response.body()
                } else {
                    // Handle unsuccessful response
                }
            } catch (e: HttpException) {
                // Handle network errors
            }
        }
    }

}
